import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  //imports: [RouterOutlet],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('ejercio01');
  texto: string = '';        // Guarda lo escrito en el input

  calculaTexto() {
    const result = this.texto;
    const long = result.length;
    return `${result} tiene ${long} caracteres`
  }
}
